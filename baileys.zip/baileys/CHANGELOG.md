# 6.1.0 (2023-05-26)


### Bug Fixes

* onWhatsApp query for multiple jids ([#85](https://github.com/WhiskeySockets/Baileys/issues/85)) ([bb25723](https://github.com/WhiskeySockets/Baileys/commit/bb25723b6ac019ec790c22b95738cc14a725f32a))



